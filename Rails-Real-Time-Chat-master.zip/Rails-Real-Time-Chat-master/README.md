# Ruby on Rails Real Time Chat

[![Build Status](https://travis-ci.org/ConPanna/Rails-Real-Time-Chat.svg?branch=master)](https://travis-ci.org/ConPanna/Rails-Real-Time-Chat)
[![VersionEye](https://img.shields.io/versioneye/d/ruby/rails.svg)]()
[![Gem](https://img.shields.io/gem/dtv/rails.svg)]()
![Npm version](https://img.shields.io/npm/v/npm.svg)
[![npm](https://img.shields.io/npm/dt/express.svg)]()
![Node version](https://img.shields.io/node/v/gh-badges.svg)

[conpanna.net](http://conpanna.net)
